			
<!-- admin menu -->
<div class="fa fa-ambulance"></div>
<div class="fa fa-h-square"></div>
<div class="fa fa-hospital-o"></div>
<div class="fa fa-medkit"></div>
<div class="fa fa-plus-square"></div>
<div class="fa fa-stethoscope"></div>
<div class="fa fa-user-md"></div>
<div class="fa fa-wheelchair"></div>