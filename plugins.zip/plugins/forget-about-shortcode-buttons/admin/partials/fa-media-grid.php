			
<!-- admin menu -->
<div class="fa fa-arrows-alt"></div>
<div class="fa fa-backward"></div>
<div class="fa fa-compress"></div>
<div class="fa fa-eject"></div>
<div class="fa fa-expand"></div>
<div class="fa fa-fast-backward"></div>
<div class="fa fa-fast-forward"></div>
<div class="fa fa-forward"></div>
<div class="fa fa-pause"></div>
<div class="fa fa-play"></div>
<div class="fa fa-play-circle"></div>
<div class="fa fa-play-circle-o"></div>
<div class="fa fa-step-backward"></div>
<div class="fa fa-step-forward"></div>
<div class="fa fa-stop"></div>
<div class="fa fa-youtube-play"></div>
