			
<!-- admin menu -->
<div class="fa fa-bitcoin"></div>
<div class="fa fa-btc"></div>
<div class="fa fa-cny"></div>
<div class="fa fa-dollar"></div>
<div class="fa fa-eur"></div>
<div class="fa fa-euro"></div>
<div class="fa fa-gbp"></div>
<div class="fa fa-inr"></div>
<div class="fa fa-jpy"></div>
<div class="fa fa-krw"></div>
<div class="fa fa-money"></div>
<div class="fa fa-rmb"></div>
<div class="fa fa-rouble"></div>
<div class="fa fa-rub"></div>
<div class="fa fa-ruble"></div>
<div class="fa fa-rupee"></div>
<div class="fa fa-try"></div>
<div class="fa fa-turkish-lira"></div>
<div class="fa fa-usd"></div>
<div class="fa fa-won"></div>
<div class="fa fa-yen"></div>

